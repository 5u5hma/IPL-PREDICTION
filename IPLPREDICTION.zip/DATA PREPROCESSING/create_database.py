import sqlite3 as sql
con = sql.connect("/Users/studies/Desktop/ipl/ipl_database.sql")
cur = con.cursor()

cur.execute("""DROP TABLE bowler_batsman_stat""")
cur.execute("""DROP TABLE bowler_stat""")
cur.execute("""DROP TABLE batsman_stat""")


sql_query = """
CREATE TABLE bowler_batsman_stat (
batsman VARCHAR(100),
bowler VARCHAR(100),
ones int(10) DEFAULT 0,
twos int(10) DEFAULT 0,
threes int(10) DEFAULT 0,
fours int(10) DEFAULT 0,
fives int(10) DEFAULT 0,
sixs int(10) DEFAULT 0,
runs int(10) DEFAULT 0,
balls_faced int(10) DEFAULT 0,
outs int(10) DEFAULT 0,
PRIMARY KEY(batsman,bowler)
);
"""

cur.execute(sql_query)

sql_query = """
CREATE TABLE bowler_stat (
bowler VARCHAR(100) PRIMARY KEY,
matches int(10) DEFAULT 0,
balls int(10) DEFAULT 0,
wickets int(10) DEFAULT 0,
runs int(10) DEFAULT 0,
average float(10) DEFAULT 0
);
"""

cur.execute(sql_query)

sql_query = """
CREATE TABLE batsman_stat (
batsman VARCHAR(100) PRIMARY KEY,
matches int(10) DEFAULT 0,
runs int(10) DEFAULT 0,
strike_rate float(10) DEFAULT 0,
balls_faced int(10) DEFAULT 0,
average float(10) DEFAULT 0,
outs int(10) DEFAULT 0
);
"""

cur.execute(sql_query)